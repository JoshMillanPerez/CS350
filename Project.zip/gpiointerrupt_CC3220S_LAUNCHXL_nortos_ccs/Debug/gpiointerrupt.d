# FIXED

gpiointerrupt.obj: ../gpiointerrupt.c
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stddef.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdio.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h
gpiointerrupt.obj: /Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/GPIO.h
gpiointerrupt.obj: /Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/I2C.h
gpiointerrupt.obj: /Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
gpiointerrupt.obj: /Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/dpl/HwiP.h
gpiointerrupt.obj: /Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/dpl/SemaphoreP.h
gpiointerrupt.obj: /Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/UART.h
gpiointerrupt.obj: /Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/Timer.h
gpiointerrupt.obj: syscfg/ti_drivers_config.h
gpiointerrupt.obj: /Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/devices/DeviceFamily.h

../gpiointerrupt.c:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stddef.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdio.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h:

/Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/GPIO.h:

/Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/I2C.h:

/Applications/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

/Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/dpl/HwiP.h:

/Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/dpl/SemaphoreP.h:

/Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/UART.h:

/Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/drivers/Timer.h:

syscfg/ti_drivers_config.h:

/Users/joshmillan_/ti/simplelink_cc32xx_sdk_4_30_00_06/source/ti/devices/DeviceFamily.h:

